package aquarium.core;

import aquarium.common.ConstantMessages;
import aquarium.common.ExceptionMessages;
import aquarium.models.aquariums.Aquarium;
import aquarium.models.aquariums.FreshwaterAquarium;
import aquarium.models.aquariums.SaltwaterAquarium;
import aquarium.models.decorations.Decoration;
import aquarium.models.decorations.Ornament;
import aquarium.models.decorations.Plant;
import aquarium.models.fish.Fish;
import aquarium.models.fish.FreshwaterFish;
import aquarium.models.fish.SaltwaterFish;
import aquarium.repositories.DecorationRepository;

import java.util.ArrayList;
import java.util.Collection;

public class ControllerImpl implements Controller{
    private DecorationRepository decorations;
    private Collection<Aquarium> aquariums;

    public ControllerImpl() {
        decorations = new DecorationRepository();
        aquariums = new ArrayList<>();
    }

    @Override
    public String addAquarium(String aquariumType, String aquariumName) {
        Aquarium aquarium;
        if (aquariumType.equals("FreshwaterAquarium")){
            aquarium = new FreshwaterAquarium(aquariumName);
        }else if (aquariumType.equals("SaltwaterAquarium")){
            aquarium = new SaltwaterAquarium(aquariumName);
        }else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_AQUARIUM_TYPE);
        }
        aquariums.add(aquarium);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_AQUARIUM_TYPE, aquariumType);
    }

    @Override
    public String addDecoration(String type) {
        Decoration decoration;
        if (type.equals("Ornament")){
            decoration = new Ornament();
        }else if (type.equals("Plant")){
            decoration = new Plant();
        }else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_DECORATION_TYPE);
        }
        decorations.add(decoration);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_DECORATION_TYPE, type);
    }

    @Override
    public String insertDecoration(String aquariumName, String decorationType) {
        Decoration decoration = decorations.findByType(decorationType);
        if (decoration == null){
            throw new IllegalArgumentException(String.format(ExceptionMessages.NO_DECORATION_FOUND, decorationType));
        }
        Aquarium aquarium = searchAquarium(aquariumName);
        for (Aquarium aquarium1 : aquariums) {
            if (aquarium1.getName().equals(aquariumName)){
                aquarium = aquarium1;
            }
        }
        if (aquarium != null){
            aquarium.addDecoration(decoration);
            decorations.remove(decoration);
            return String.format(ConstantMessages.SUCCESSFULLY_ADDED_DECORATION_IN_AQUARIUM, decorationType, aquariumName);
        }
        return null;
    }

    private Aquarium searchAquarium(String aquariumName) {
        for (Aquarium aquarium1 : aquariums) {
            if (aquarium1.getName().equals(aquariumName)){
                return aquarium1;
            }
        }
        return null;
    }

    @Override
    public String addFish(String aquariumName, String fishType, String fishName, String fishSpecies, double price) {
        Aquarium aquarium = searchAquarium(aquariumName);
        Fish fish;
        if (fishType.equals("FreshwaterFish")){
            fish = new FreshwaterFish(fishName, fishSpecies, price);
        }else if (fishType.equals("SaltwaterFish")){
            fish = new SaltwaterFish(fishName, fishSpecies, price);
        }else {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_FISH_TYPE);
        }
        if (aquarium!=null){
            if (isValid(aquarium, fish)){
                aquarium.addFish(fish);
                return String.format(ConstantMessages.SUCCESSFULLY_ADDED_FISH_IN_AQUARIUM, fishType, aquariumName);
            }else {
                return ConstantMessages.WATER_NOT_SUITABLE;
            }
        }
        return null;
    }

    private boolean isValid(Aquarium aquarium, Fish fish) {
        return aquarium.getClass().getSimpleName().equals("FreshwaterAquarium") && fish.getClass().getSimpleName().equals("FreshwaterFish") ||
                aquarium.getClass().getSimpleName().equals("SaltwaterAquarium") && fish.getClass().getSimpleName().equals("SaltwaterFish");
    }

    @Override
    public String feedFish(String aquariumName) {
        Aquarium aquarium = searchAquarium(aquariumName);
        if (aquarium != null) {
            aquarium.feed();
        }
        return String.format(ConstantMessages.FISH_FED, aquarium.getFish().size());
    }

    @Override
    public String calculateValue(String aquariumName) {
        Aquarium aquarium = searchAquarium(aquariumName);
        double sum = 0;
        if (aquarium!=null){
        if (!aquarium.getFish().isEmpty()){
        for (Fish fish : aquarium.getFish()) {
            sum+=fish.getPrice();
        }
        }

        for (Decoration decoration : aquarium.getDecorations()) {
            sum += decoration.getPrice();
        }
        return String.format(ConstantMessages.VALUE_AQUARIUM, aquariumName, sum);
        }
        return null;
    }

    @Override
    public String report() {
        StringBuilder sb = new StringBuilder();
        for (Aquarium aquarium : aquariums) {
            sb.append(aquarium.getInfo()).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }
}
