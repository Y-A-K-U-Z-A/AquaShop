package aquarium.models.aquariums;

import aquarium.models.fish.Fish;

public class FreshwaterAquarium extends BaseAquarium{
    public FreshwaterAquarium(String name) {
        super(name, 50);
    }

}
